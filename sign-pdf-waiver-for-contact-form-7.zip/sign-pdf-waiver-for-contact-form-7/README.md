# CF7 PDF Waiver — WordPress Plugin

Converts an uploaded PDF waiver into a Contact Form 7-compatible input form with a canvas signature field. Logs each submission's timestamp, IP address, and drawn signature to a custom database table.

---

## Requirements

| Dependency | Version |
|---|---|
| WordPress | 5.9+ |
| PHP | 8.0+ |
| Contact Form 7 | 5.7+ |

---

## Installation

1. Copy the `cf7-waiver-plugin/` folder into `wp-content/plugins/`.
2. Install the real Signature Pad library (the bundled one is a working stub):
   ```bash
   cd wp-content/plugins/cf7-waiver-plugin
   npm install signature_pad
   cp node_modules/signature_pad/dist/signature_pad.umd.min.js assets/js/
   ```
   **Or** switch to CDN delivery: in `cf7-waiver-plugin.php`, replace the `signature-pad` registration URL with:
   ```
   https://cdn.jsdelivr.net/npm/signature_pad@4.1.7/dist/signature_pad.umd.min.js
   ```
3. (Optional) For better PDF field extraction, install the PDF parser via Composer:
   ```bash
   composer require smalot/pdfparser
   ```
4. Activate the plugin in **WordPress Admin → Plugins**.

---

## Usage

### Step 1 — Configure a CF7 Form

1. Go to **Contact → Contact Forms** and open (or create) a form.
2. In the **PDF Waiver Settings** meta box:
   - Upload your waiver PDF via **Upload PDF**.
   - The plugin parses the PDF and populates the field table automatically.
   - Review / edit / reorder the fields.
   - Set a notification email address.
3. Save the form.

### Step 2 — Embed the Form

Add the shortcode anywhere (page, post, widget):

```
[cf7_waiver id="YOUR_FORM_ID"]
```

Replace `YOUR_FORM_ID` with the CF7 post ID (visible in the URL when editing the form).

---

## PDF Parsing

The plugin uses a three-stage strategy:

1. **smalot/pdfparser** (best) — if installed via Composer, extracts labelled fields from PDF text.
2. **Raw byte scanning** — reads AcroForm `/T` entries from the PDF binary (works for fillable PDFs).
3. **Default fields** — falls back to a sensible generic waiver field set if parsing yields nothing.

---

## Submissions Log

View all signed waivers at **Contact → Waiver Submissions**.

Each row shows:
- Entry ID, Form, Date/Time
- IP Address
- Collapsed field values (click to expand)
- Signature image preview

---

## Database Table

`wp_cf7_waiver_logs`

| Column | Type | Description |
|---|---|---|
| `id` | BIGINT | Auto-increment primary key |
| `form_id` | BIGINT | CF7 form post ID |
| `entry_date` | DATETIME | Server time of submission |
| `ip_address` | VARCHAR(45) | Client IP (IPv4/IPv6) |
| `user_agent` | TEXT | Browser user-agent string |
| `form_data` | LONGTEXT | JSON-encoded field values |
| `signature` | LONGTEXT | Base64 PNG data URI |

---

## Hooks

| Hook | Description |
|---|---|
| `cf7w_submission_complete` | Fires after a successful submission. Args: `$form_id`, `$form_data`, `$entry_id` |

Example:
```php
add_action('cf7w_submission_complete', function($form_id, $form_data, $entry_id) {
    // e.g. push data to a CRM
}, 10, 3);
```

---

## File Structure

```
cf7-waiver-plugin/
├── cf7-waiver-plugin.php          # Plugin bootstrap
├── includes/
│   ├── class-pdf-parser.php       # PDF → field extraction
│   ├── class-form-builder.php     # Frontend form HTML renderer
│   └── class-submission-handler.php # AJAX handler + DB logging
├── admin/
│   └── class-admin.php            # WP admin UI + meta box
├── assets/
│   ├── css/
│   │   ├── waiver.css             # Frontend styles
│   │   └── admin.css              # Admin styles
│   └── js/
│       ├── signature_pad.min.js   # Signature Pad (replace with real lib)
│       ├── signature.js           # Frontend pad init + AJAX submit
│       └── admin.js               # Admin PDF upload + field editor
└── README.md
```

---

## License

GPL-2.0-or-later
